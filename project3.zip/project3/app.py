import os
import csv
from flask import Blueprint, render_template, redirect, url_for, request,flash,Flask,send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from .models import User,Genre,Rating,Search_history
from . import db
from flask_login import login_user, logout_user, login_required,current_user
from pandas import DataFrame, read_csv
import json
import sqlalchemy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD
import pandas as pd
import numpy as np

auth = Blueprint('auth', __name__)


#movies = pd.read_sql_table('moviessmall',engine)
#Final = pd.read_sql_table('Final',db)
#ratings = pd.read_sql_table('ratingssmall',db)
movies = pd.read_csv('/home/induja/flask_auth_app/project3/moviessmall.csv')
Final = pd.read_csv('/home/induja/flask_auth_app/project3/Final.csv')
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(Final['metadata'])

ratings = pd.read_csv('/home/induja/flask_auth_app/project3/ratingssmall.csv')

movies = movies.reset_index()
indices = pd.Series(movies.index, index=movies['title'])
all_titles = [movies['title'][i] for i in range(len(movies['title']))]

def recommend_similar(title):
    tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), index = Final.index.tolist())
    svd = TruncatedSVD(n_components=200)
    latent_matrix = svd.fit_transform(tfidf_df)
    n=200
    latent_matrix_1_df = pd.DataFrame(latent_matrix[:,0:n], index= Final.title.tolist())
    #take the latent vectors for a selected movie from both content and collaborative matrices
    a_1 = np.array(latent_matrix_1_df.loc[title]).reshape(1, -1)

    #calculate the similarity of this movie with other in the list
    score_1 = cosine_similarity(latent_matrix_1_df, a_1).reshape(-1)
    #form a dataframe of similar movies
    dictDf = {'content': score_1 }# 'collaborative': score_2, 'hybrid': hybrid}
    similar = pd.DataFrame(dictDf, index = latent_matrix_1_df.index )
    #sort it on the basis of either content ,collaborative or hybrid,
    similar.sort_values('content', ascending=False, inplace=True)
    similar.head(6)
    similar = pd.DataFrame(similar)
    similar['title']=similar.index
    result = pd.merge(similar,movies, on='title')
    result = pd.DataFrame(result)
    return result


def recommend_colab(title):
    ratings_f1=ratings.drop("Unnamed: 0",axis=1)
    ratings_f2 = ratings_f1.pivot(index='movieId', columns='userId' , values='rating').fillna(0)
    svd = TruncatedSVD(n_components=200)
    latent_matrix_2 = svd.fit_transform(ratings_f2)
    latent_matrix_2_df = pd.DataFrame(latent_matrix_2, index=Final.title.tolist())
    a_2 = np.array(latent_matrix_2_df.loc[title]).reshape(1, -1)
    score_2 = cosine_similarity(latent_matrix_2_df, a_2).reshape(-1)
    dictDf = {'collaborative': score_2}# 'hybrid': hybrid}
    colab = pd.DataFrame(dictDf, index = latent_matrix_2_df.index )

    #sort it on the basis of either content ,collaborative or hybrid,
    colab.sort_values('collaborative', ascending=False, inplace=True)
    colab[1:].head()
    colab = pd.DataFrame(colab)
    colab['title']=colab.index
    result = pd.merge(colab,movies, on='title')
    result = pd.DataFrame(result)
    return result


def top_rating():
    movies = pd.read_csv('/home/induja/flask_auth_app/project3/moviessmall.csv')
    movies=movies.drop("Unnamed: 0",axis=1)
    ratings = pd.read_csv('/home/induja/flask_auth_app/project3/ratingssmall.csv')
    ## Top rated movies
  
    top_data =pd.merge(ratings,movies,on='movieId')
    trend=pd.DataFrame(top_data.groupby('title')['rating'].mean())
    trend['total number of ratings'] = pd.DataFrame(top_data.groupby('title')['rating'].count()) 
    top_data =top_data.groupby('title')['rating'].mean().sort_values(ascending=False)
    top_rated=pd.merge(top_data,movies,on='title')
    top_rated =top_rated[1:11]
    top = pd.DataFrame(top_rated)
    return top
    

@auth.route('/home')
def index():
    try:
        return render_template("profile.html")
    except Exception as e:
        return str(e)

@auth.route('/positive')
def positive():
    try:
        return render_template("positive.html")
    except Exception as e:
        return str(e)

@auth.route('/negative')
def negative():
    try:
        return render_template("negative.html",name=m_name, all_titles=all_titles)
    except Exception as e:
        return str(e)


@app.route('/')
def home():
    try:
        top = top_rating()
        mid = top['movieId'].values.tolist()
        title= top['title'].values.tolist()
        tmdb = top['tmdbId'].values.tolist()
        year = top['year'].to_list()
        genres = top['genres'].to_list()
        return render_template("profile.html", movies=top, movieid=mid, movie_name=title ,tmdb=tmdb, year=year, genres=genres)
    except Exception as e:
        return str(e)

@auth.route('/home', methods=['GET']) 
def search():
    try:
        if request.method == 'GET':
            titles = movies['title'].values.to_list()
            return render_template("profile.html", titles= titles)
    except Exception as e:
        return str(e)

@auth.route('/positive', methods=['GET','POST'])
def main():
    try:
       
        if request.method == 'POST':
            m_name = request.form['movie_name']
            m_name = m_name.title()
            if m_name not in all_titles:
                return render_template('negative.html')
        #if request.method == 'POST':
           # m_name = request.form['movie_name']
           # titles = all_titles()
           # if m_name not in titles:
           #     return render_template('negative.html')
            else:
                with open('/home/induja/flask_auth_app/project3/movieR.csv', 'a',newline='') as csv_file:
                    fieldnames = ['Movie']
                    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
                    writer.writerow({'Movie': m_name})
                details = movies.loc[movies['title'] == m_name]
                tmdb = details['tmdbId'].to_list()
            
                content = recommend_similar(m_name)
                movie_name = content['title'].to_list()
                movieId    = content['tmdbId'].to_list()
                movie_year = content['year'].to_list()
                genres  = content['genres'].to_list()

                colab = recommend_colab(m_name)
                colab_name = colab['title'].to_list()
                colab_id = colab['tmdbId'].to_list()
                colab_year= colab['year'].to_list()
                colab_genre = colab['genres'].to_list()

                return render_template('positive.html',  name=m_name, tmdb=tmdb, movie_name=movie_name, movieId=movieId, movie_year=movie_year, movie_genre=genres)
    except Exception as e:
        return str(e)          
        


@auth.route('/login')
def login():
    return render_template('login.html')   

@auth.route('/login', methods=['POST'])
def login_post():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()
        if user:
            if check_password_hash(user.password, password):
               # flash('Logged in successfully!', category='success')
                login_user(user, remember=True)
                return redirect(url_for('auth.profile'))
            else:
                flash('Incorrect password, try again.', category='error')
        else:
            flash('Email does not exist.', category='error')

    return render_template("login.html", user=current_user)

@auth.route('/signup')
def signup():
    return render_template('signup.html')
    
@aut.route('/signup', methods=['POST'])
def signup_post():
 if request.method == 'POST':
    email = request.form.get('email')
    name = request.form.get('name')
    password = request.form.get('password')
    confirm = request.form.get('confirm')
    user = User.query.filter_by(email=email).first() # if this returns a user, then the email already exists in database

    if user: # if a user is found, we want to redirect back to signup page so user can try again
        flash('Email address already exists')
        return redirect(url_for('auth.signup'))
        
    elif password != confirm:
        flash('Passwords dont match.', category='error') 
    # create a new user with the form data. Hash the password so the plaintext version isn't saved.
    else:
        new_user = User(email=email, name=name, password=generate_password_hash(password, method='sha256'))

    # add the new user to the database
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user)
        return redirect(url_for('auth.genre'))
        
    return render_template("signup.html", user=current_user)   
@app.route('/genre', methods=['POST'])
def genre_post():
    genres=""
    for x in request.form.getlist('mycheckbox'):
	      genres+=x
	      genres+="|"
    new_user = Genre(genres=genres)
    
    # add the new user to the database
    db.session.add(new_user)
    db.session.commit()
    
    return redirect(url_for('auth.profile'))
    
@app.route('/genre')
def genre():
    return render_template('genre.html') 
    
@app.route('/rating')
def rating():
    return render_template('rating.html')  
    
@app.route('/rating', methods=['POST'])
def rating_post():
    rating = request.form.get('rating')
    new_user = Rating(userid=current_user.id,rating=rating)
    
     # add the new user to the database
    db.session.add(new_user)
    db.session.commit()
    
    return redirect(url_for('auth.profile'))
   

@app.route('/profile')
@login_required
def profile():
    try:
        top = top_rating()
        mid = top['movieId'].values.tolist()
        title= top['title'].values.tolist()
        tmdb = top['tmdbId'].values.tolist()
        year = top['year'].to_list()
        genres = top['genres'].to_list()
        return render_template("profile.html", movies=top, movieid=mid, movie_name=title ,tmdb=tmdb, year=year, genres=genres)
    except Exception as e:
        return str(e)


@app.route('/profile', methods=['POST'])
def profile_post():
    movie = request.form.get('movie')
    new_user = Search_history(userid=current_user.id,movie=movie)
    
    # add the new user to the database
    db.session.add(new_user)
    db.session.commit()
    
    return redirect(url_for('auth.positive'))   



@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))
    
